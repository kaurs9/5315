{
  "data": [
    {
      "name": "Sunita Kaur",
      "occupation": "Scientist",
      "sold_price": "$70,750",
      "purchase_date": "2012/10/12",
      "location": "Seattle",
      "cust_id": "0011"
    },
    {
      "name": "Jane Doe",
      "occupation": "Product Manager",
      "sold_price": "150,000",
      "purchase_date": "2016/12/02",
      "location": "Dubai",
      "cust_id": "0012"
    },
    {
      "name": "John Smith",
      "occupation": "Student",
      "sold_price": "$10000",
      "purchase_date": "2005/01/12",
      "location": "San Francisco",
      "cust_id": "0013"
    },
     {
      "name": "Bill Johnson",
      "occupation": "Salesman",
      "sold_price": "$30,900",
      "purchase_date": "2011/07/23",
      "location": "Dallas",
      "cust_id": "0014"
    },
    {
      "name": "Kelly Kapp",
      "occupation": "Sales Manager",
      "sold_price": "90,030",
      "purchase_date": "2003/05/02",
      "location": "Delhi",
      "cust_id": "0015"
    },
    {
      "name": "Dan Harten",
      "occupation": "Educator",
      "sold_price": "$100,000",
      "purchase_date": "2015/11/12",
      "location": "San Francisco",
      "cust_id": "0016"
    }
  ]
}